package io.pivotal.data.config;

public class CloudCacheConfig {


}
